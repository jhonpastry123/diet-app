# Fitness Application (Android)

This is Fitness android application.

There are several features.
- Lose weight
- Keep weight
- Gain weight

Lose weight is the main feature.

For 24 hours, user can use this app free. After trial period passed, if user is going to use it, user has to pay.

There are 2 membership plans.
- Bronze plan ( 3 euro per month )
- Gold plan (49.99 euro per month )
