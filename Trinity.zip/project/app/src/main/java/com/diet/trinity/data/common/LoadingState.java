package com.diet.trinity.data.common;

public enum LoadingState {
    IDLE,
    ERROR,
    LOADED,
    LOADING,
}
