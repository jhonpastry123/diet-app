package com.diet.trinity.data.common;

public enum Gender {
    MALE, FEMALE
}
