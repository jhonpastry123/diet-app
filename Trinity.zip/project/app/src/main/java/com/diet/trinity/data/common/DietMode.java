package com.diet.trinity.data.common;

public enum DietMode {
    POINT, UNIT
}
