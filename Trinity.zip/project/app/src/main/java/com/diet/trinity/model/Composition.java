package com.diet.trinity.model;

public class Composition {
    int proteins, carbs, fat;
}
