package com.diet.trinity.Utility;

public class FoodItems {

    private String FoodName;

    public FoodItems(String FoodName) {
        this.FoodName = FoodName;
    }

    public String getFoodName() {
        return this.FoodName;
    }
}
