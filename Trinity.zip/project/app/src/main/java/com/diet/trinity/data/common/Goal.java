package com.diet.trinity.data.common;

public enum Goal {
    LOSE, GAIN, STAY;
}
